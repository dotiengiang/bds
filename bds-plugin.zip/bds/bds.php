<?php
/*
Plugin Name: Quản lý dự án
*/

if ( ! function_exists('quen_bds') ) {

// Register Custom Post Type
function quen_bds() {

	$labels = array(
		'name'                  => _x( 'Dự án', 'Post Type General Name', 'quen' ),
		'singular_name'         => _x( 'Dự án', 'Post Type Singular Name', 'quen' ),
		'menu_name'             => __( 'Dự án', 'quen' ),
		'name_admin_bar'        => __( 'Dự án', 'quen' ),
		'archives'              => __( 'Dự án', 'quen' ),
		'attributes'            => __( 'Các dự án', 'quen' ),
		'parent_item_colon'     => __( 'Dự án', 'quen' ),
		'all_items'             => __( 'Tất cả các dự án', 'quen' ),
		'add_new_item'          => __( 'Thêm dự án mới', 'quen' ),
		'add_new'               => __( 'Thêm dự án mới', 'quen' ),
		'new_item'              => __( 'Dự án mới', 'quen' ),
		'edit_item'             => __( 'Sửa dự án', 'quen' ),
		'update_item'           => __( 'Cập nhật', 'quen' ),
		'view_item'             => __( 'Xem dự án', 'quen' ),
		'view_items'            => __( 'Xem các dự án', 'quen' ),
		'search_items'          => __( 'Tìm dự án', 'quen' ),
		'not_found'             => __( 'Không thấy', 'quen' ),
		'not_found_in_trash'    => __( 'Không có trong thùng rác', 'quen' ),
		'featured_image'        => __( 'Ảnh bìa dự án', 'quen' ),
		'set_featured_image'    => __( 'Đặt ảnh bìa cho dự án', 'quen' ),
		'remove_featured_image' => __( 'Xoá bỏ ảnh bìa dự án', 'quen' ),
		'use_featured_image'    => __( 'Dùng làm ảnh bìa dự án', 'quen' ),
		'insert_into_item'      => __( 'Chèn', 'quen' ),
		'uploaded_to_this_item' => __( 'Tải lên', 'quen' ),
		'items_list'            => __( 'Danh sách', 'quen' ),
		'items_list_navigation' => __( 'Điều hướng', 'quen' ),
		'filter_items_list'     => __( 'Lọc', 'quen' ),
	);
	$rewrite = array(
		'slug'                  => 'du-an',
		'with_front'            => true,
		'pages'                 => true,
		'feeds'                 => true,
	);
	$args = array(
		'label'                 => __( 'Dự án', 'quen' ),
		'description'           => __( 'Quản lý dự án Dự án', 'quen' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'thumbnail', 'comments', 'trackbacks' ),
		'taxonomies'            => array( 'bds_type', ' bds_location', ' bds_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-building',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => 'du-an',
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'rewrite'               => $rewrite,
		'capability_type'       => 'post',
		'show_in_rest'          => true,
	);
	register_post_type( 'bds', $args );

}
add_action( 'init', 'quen_bds', 0 );

}

if ( ! function_exists( 'quen_bds_location' ) ) {

// Register Custom Taxonomy
function quen_bds_location() {

	$labels = array(
		'name'                       => _x( 'Vị trí dự án', 'Taxonomy General Name', 'quen' ),
		'singular_name'              => _x( 'Vị trí dự án', 'Taxonomy Singular Name', 'quen' ),
		'menu_name'                  => __( 'Vị trí dự án', 'quen' ),
		'all_items'                  => __( 'Tất các các vị trí', 'quen' ),
		'parent_item'                => __( 'Vị trí', 'quen' ),
		'parent_item_colon'          => __( 'Vị trí', 'quen' ),
		'new_item_name'              => __( 'Thêm vị trí', 'quen' ),
		'add_new_item'               => __( 'Thêm vị trí', 'quen' ),
		'edit_item'                  => __( 'Sửa', 'quen' ),
		'update_item'                => __( 'Cập nhật', 'quen' ),
		'view_item'                  => __( 'Xem', 'quen' ),
		'separate_items_with_commas' => __( '', 'quen' ),
		'add_or_remove_items'        => __( 'Thêm hoặc xoá', 'quen' ),
		'choose_from_most_used'      => __( 'Chọn vị trí nhiều dự án', 'quen' ),
		'popular_items'              => __( 'Vị trí phổ biến', 'quen' ),
		'search_items'               => __( 'Tìm', 'quen' ),
		'not_found'                  => __( 'Không thấy', 'quen' ),
		'no_terms'                   => __( 'Không có', 'quen' ),
		'items_list'                 => __( 'Danh sách', 'quen' ),
		'items_list_navigation'      => __( 'Điều hướng', 'quen' ),
	);
	$rewrite = array(
		'slug'                       => 'vi-tri',
		'with_front'                 => true,
		'hierarchical'               => true,
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => false,
		'rewrite'                    => $rewrite,
		'show_in_rest'               => true,
	);
	register_taxonomy( 'bds_location', array( 'bds' ), $args );

}
add_action( 'init', 'quen_bds_location', 0 );

}

if ( ! function_exists( 'quen_bds_type' ) ) {

// Register Custom Taxonomy
function quen_bds_type() {

	$labels = array(
		'name'                       => _x( 'Phân loại dự án', 'Taxonomy General Name', 'quen' ),
		'singular_name'              => _x( 'Phân loại dự án', 'Taxonomy Singular Name', 'quen' ),
		'menu_name'                  => __( 'Loại dự án', 'quen' ),
		'all_items'                  => __( 'Tất cả các loại dự án', 'quen' ),
		'parent_item'                => __( 'Loại dự án', 'quen' ),
		'parent_item_colon'          => __( 'Loại dự án', 'quen' ),
		'new_item_name'              => __( 'Thêm loại dự án', 'quen' ),
		'add_new_item'               => __( 'Thêm loại dự án', 'quen' ),
		'edit_item'                  => __( 'Sửa', 'quen' ),
		'update_item'                => __( 'Cập nhật', 'quen' ),
		'view_item'                  => __( 'Xem', 'quen' ),
		'separate_items_with_commas' => __( '', 'quen' ),
		'add_or_remove_items'        => __( 'Thêm hoặc xoá', 'quen' ),
		'choose_from_most_used'      => __( 'Chọn loại nhiều dự án', 'quen' ),
		'popular_items'              => __( 'Loại dự án phổ biến', 'quen' ),
		'search_items'               => __( 'Tìm', 'quen' ),
		'not_found'                  => __( 'Không thấy', 'quen' ),
		'no_terms'                   => __( 'Không có', 'quen' ),
		'items_list'                 => __( 'Danh sách', 'quen' ),
		'items_list_navigation'      => __( 'Điều hướng', 'quen' ),
	);
	$rewrite = array(
		'slug'                       => 'loai-du-an',
		'with_front'                 => true,
		'hierarchical'               => true,
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => false,
		'rewrite'                    => $rewrite,
		'show_in_rest'               => true,
	);
	register_taxonomy( 'bds_type', array( 'bds' ), $args );

}
add_action( 'init', 'quen_bds_type', 0 );

}

if ( ! function_exists( 'quen_bds_tag' ) ) {

// Register Custom Taxonomy
function quen_bds_tag() {

	$labels = array(
		'name'                       => _x( 'Gắn thẻ dự án', 'Taxonomy General Name', 'quen' ),
		'singular_name'              => _x( 'Gắn thẻ dự án', 'Taxonomy Singular Name', 'quen' ),
		'menu_name'                  => __( 'Gắn thẻ dự án', 'quen' ),
		'all_items'                  => __( 'Tất các các thẻ', 'quen' ),
		'parent_item'                => __( 'Thẻ dự án', 'quen' ),
		'parent_item_colon'          => __( 'Thẻ dự án', 'quen' ),
		'new_item_name'              => __( 'Thêm thẻ mới', 'quen' ),
		'add_new_item'               => __( 'Thêm thẻ mới', 'quen' ),
		'edit_item'                  => __( 'Sửa', 'quen' ),
		'update_item'                => __( 'Cập nhật', 'quen' ),
		'view_item'                  => __( 'Xem', 'quen' ),
		'separate_items_with_commas' => __( '', 'quen' ),
		'add_or_remove_items'        => __( 'Thêm hoặc xoá', 'quen' ),
		'choose_from_most_used'      => __( 'Chọn thẻ dùng nhiều', 'quen' ),
		'popular_items'              => __( 'Thẻ phổ biến', 'quen' ),
		'search_items'               => __( 'Tìm', 'quen' ),
		'not_found'                  => __( 'Không thấy', 'quen' ),
		'no_terms'                   => __( 'Không có', 'quen' ),
		'items_list'                 => __( 'Danh sách', 'quen' ),
		'items_list_navigation'      => __( 'Điều hướng', 'quen' ),
	);
	$rewrite = array(
		'slug'                       => 'the-du-an',
		'with_front'                 => true,
		'hierarchical'               => true,
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => false,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
		'rewrite'                    => $rewrite,
		'show_in_rest'               => true,
	);
	register_taxonomy( 'bds_tag', array( 'bds' ), $args );

}
add_action( 'init', 'quen_bds_tag', 0 );

}